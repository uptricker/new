'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { FaUser, FaLock, FaRocket, FaShieldAlt, FaBolt, FaCrown } from 'react-icons/fa';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    if (!isLogin && password !== confirmPassword) {
      setMessage({ type: 'error', text: '❌ Passwords do not match!' });
      setLoading(false);
      return;
    }

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/signup';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage({ type: 'success', text: `✅ ${data.message}` });
        if (isLogin) {
          setTimeout(() => router.push('/dashboard'), 1000);
        } else {
          setTimeout(() => {
            setIsLogin(true);
            setPassword('');
            setConfirmPassword('');
          }, 1500);
        }
      } else {
        setMessage({ type: 'error', text: `❌ ${data.message}` });
      }
    } catch (error) {
      setMessage({ type: 'error', text: '❌ An error occurred. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-pink-300/30 to-purple-300/30 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-indigo-300/30 to-pink-300/30 rounded-full blur-3xl animate-pulse-slow"></div>
      </div>

      <div className="w-full max-w-6xl relative z-10 grid md:grid-cols-2 gap-8">
        {/* Left side - Branding */}
        <div className="hidden md:flex flex-col justify-center items-start p-12 glass-card rounded-3xl">
          <div className="mb-8">
            <h1 className="text-6xl font-black mb-4 gradient-text">
              🦂 YKTI RAWAT
            </h1>
            <p className="text-2xl font-bold text-gray-700 mb-6">
              PREMIUM FB E2EE AUTOMATION SYSTEM
            </p>
            <div className="h-1 w-32 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"></div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl">
                <FaShieldAlt className="text-white text-2xl" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-800">Secure & Encrypted</h3>
                <p className="text-gray-600">End-to-end encrypted communications</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl">
                <FaBolt className="text-white text-2xl" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-800">Lightning Fast</h3>
                <p className="text-gray-600">Optimized for 24/7 performance</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gradient-to-br from-indigo-500 to-pink-600 rounded-xl">
                <FaCrown className="text-white text-2xl" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-800">Premium Features</h3>
                <p className="text-gray-600">Multiple cookies, file uploads & more</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login/Signup Form */}
        <div className="glass-card rounded-3xl p-8 md:p-12 pulse-glow">
          <div className="text-center mb-8">
            <div className="inline-block p-4 bg-gradient-to-br from-pink-500 to-purple-600 rounded-2xl mb-4">
              <FaRocket className="text-white text-4xl" />
            </div>
            <h2 className="text-3xl font-black gradient-text mb-2">
              {isLogin ? 'WELCOME BACK!' : 'JOIN US TODAY!'}
            </h2>
            <p className="text-gray-600 font-medium">
              {isLogin ? 'Login to continue your automation' : 'Create your premium account'}
            </p>
          </div>

          {/* Tab Switcher */}
          <div className="flex gap-2 mb-8 p-1 bg-gray-100 rounded-xl">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 px-6 rounded-lg font-bold transition-all duration-300 ${
                isLogin
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              🔐 LOGIN
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 px-6 rounded-lg font-bold transition-all duration-300 ${
                !isLogin
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              ✨ SIGN UP
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                <FaUser className="inline mr-2" />
                USERNAME
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="input-field"
                placeholder="Enter your username"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                <FaLock className="inline mr-2" />
                PASSWORD
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field"
                placeholder="Enter your password"
                required
              />
            </div>

            {!isLogin && (
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  <FaLock className="inline mr-2" />
                  CONFIRM PASSWORD
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="input-field"
                  placeholder="Re-enter your password"
                  required
                />
              </div>
            )}

            {message.text && (
              <div
                className={`p-4 rounded-xl font-bold ${
                  message.type === 'success'
                    ? 'bg-green-100 text-green-700 border-2 border-green-300'
                    : 'bg-red-100 text-red-700 border-2 border-red-300'
                }`}
              >
                {message.text}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  PROCESSING...
                </span>
              ) : (
                <span className="text-lg">
                  {isLogin ? '🚀 LOGIN NOW' : '✨ CREATE ACCOUNT'}
                </span>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-gray-500 text-sm">
              {isLogin ? "Don't have an account?" : 'Already have an account?'}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="ml-2 font-bold text-pink-500 hover:text-purple-600 transition-colors"
              >
                {isLogin ? 'Sign up now!' : 'Login here!'}
              </button>
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-gray-600 font-bold text-sm">
          MADE WITH ❤️ BY YKTI RAWAT | © 2026
        </p>
      </div>
    </div>
  );
}
