'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { 
  FaUser, FaSignOutAlt, FaCog, FaRocket, FaChartLine, 
  FaCookie, FaFileUpload, FaPlay, FaStop, FaTrash,
  FaCopy, FaCheck
} from 'react-icons/fa';

interface UserConfig {
  chatId: string;
  namePrefix: string;
  delay: number;
  cookieMode: 'single' | 'multiple';
  singleCookie: string;
  multipleCookies: string;
  messages: string;
}

export default function Dashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [username, setUsername] = useState('');
  const [userId, setUserId] = useState(0);
  
  // Config state
  const [config, setConfig] = useState<UserConfig>({
    chatId: '',
    namePrefix: '',
    delay: 30,
    cookieMode: 'single',
    singleCookie: '',
    multipleCookies: '',
    messages: '',
  });

  // Automation state
  const [isRunning, setIsRunning] = useState(false);
  const [messageCount, setMessageCount] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'config' | 'automation'>('config');
  const [saveMessage, setSaveMessage] = useState({ type: '', text: '' });
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cookieFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const response = await fetch('/api/user/config');
      if (!response.ok) {
        router.push('/login');
        return;
      }
      const data = await response.json();
      setUsername(data.username);
      setUserId(data.userId);
      setConfig(data.config);
      setIsRunning(data.config.automation_running === 1);
    } catch (error) {
      router.push('/login');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  };

  const handleSaveConfig = async () => {
    try {
      const response = await fetch('/api/user/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      const data = await response.json();
      if (data.success) {
        setSaveMessage({ type: 'success', text: '✅ Configuration saved successfully!' });
        setTimeout(() => setSaveMessage({ type: '', text: '' }), 3000);
      } else {
        setSaveMessage({ type: 'error', text: '❌ Failed to save configuration' });
      }
    } catch (error) {
      setSaveMessage({ type: 'error', text: '❌ An error occurred' });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setConfig({ ...config, messages: content });
    };
    reader.readAsText(file);
  };

  const handleCookieFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (config.cookieMode === 'multiple') {
        setConfig({ ...config, multipleCookies: content });
      } else {
        setConfig({ ...config, singleCookie: content });
      }
    };
    reader.readAsText(file);
  };

  const handleStartAutomation = async () => {
    if (!config.chatId) {
      alert('❌ Please set Chat ID first!');
      return;
    }

    try {
      const response = await fetch('/api/automation/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      const data = await response.json();
      if (data.success) {
        setIsRunning(true);
        setLogs([...logs, '✅ Automation started successfully!']);
      } else {
        alert('❌ Failed to start automation: ' + data.message);
      }
    } catch (error) {
      alert('❌ An error occurred while starting automation');
    }
  };

  const handleStopAutomation = async () => {
    try {
      const response = await fetch('/api/automation/stop', { method: 'POST' });
      const data = await response.json();
      
      if (data.success) {
        setIsRunning(false);
        setLogs([...logs, '⚠️ Automation stopped']);
      }
    } catch (error) {
      alert('❌ Failed to stop automation');
    }
  };

  const copyChatId = () => {
    navigator.clipboard.writeText(config.chatId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-pink-500 mx-auto mb-4"></div>
          <p className="text-xl font-bold gradient-text">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      {/* Header */}
      <div className="glass-card rounded-3xl p-6 md:p-10 mb-8 pulse-glow">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h1 className="text-4xl md:text-5xl font-black gradient-text mb-2">
              🦂 YKTI RAWAT
            </h1>
            <p className="text-xl font-bold text-gray-700">
              PREMIUM FB E2EE AUTOMATION SERVER
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-gray-600 font-medium">Logged in as</p>
              <p className="text-lg font-bold text-pink-600">{username}</p>
            </div>
            <button
              onClick={handleLogout}
              className="btn-secondary flex items-center gap-2"
            >
              <FaSignOutAlt />
              LOGOUT
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-gray-600 font-bold">MESSAGES SENT</h3>
            <FaChartLine className="text-pink-500 text-2xl" />
          </div>
          <p className="text-4xl font-black gradient-text">{messageCount}</p>
        </div>

        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-gray-600 font-bold">STATUS</h3>
            <FaRocket className="text-pink-500 text-2xl" />
          </div>
          <p className={`text-2xl font-black ${isRunning ? 'text-green-500' : 'text-red-500'}`}>
            {isRunning ? '🟢 RUNNING' : '🔴 STOPPED'}
          </p>
        </div>

        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-gray-600 font-bold">CHAT ID</h3>
            <button onClick={copyChatId} className="text-pink-500 text-xl hover:text-pink-600">
              {copied ? <FaCheck /> : <FaCopy />}
            </button>
          </div>
          <p className="text-lg font-bold text-gray-700 truncate">
            {config.chatId || 'NOT SET'}
          </p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setActiveTab('config')}
          className={`flex-1 py-4 px-6 rounded-xl font-bold transition-all duration-300 ${
            activeTab === 'config'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
              : 'glass-card text-gray-700 hover:shadow-lg'
          }`}
        >
          <FaCog className="inline mr-2" />
          CONFIGURATION
        </button>
        <button
          onClick={() => setActiveTab('automation')}
          className={`flex-1 py-4 px-6 rounded-xl font-bold transition-all duration-300 ${
            activeTab === 'automation'
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
              : 'glass-card text-gray-700 hover:shadow-lg'
          }`}
        >
          <FaRocket className="inline mr-2" />
          AUTOMATION CONTROL
        </button>
      </div>

      {/* Configuration Tab */}
      {activeTab === 'config' && (
        <div className="glass-card rounded-3xl p-6 md:p-10 fade-in">
          <h2 className="text-3xl font-black gradient-text mb-8">⚙️ CONFIGURATION SETTINGS</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  CHAT/CONVERSATION E2EE ID
                </label>
                <input
                  type="text"
                  value={config.chatId}
                  onChange={(e) => setConfig({ ...config, chatId: e.target.value })}
                  className="input-field"
                  placeholder="e.g., 1362400298935018"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Get this from Facebook Messenger URL
                </p>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  NAME PREFIX
                </label>
                <input
                  type="text"
                  value={config.namePrefix}
                  onChange={(e) => setConfig({ ...config, namePrefix: e.target.value })}
                  className="input-field"
                  placeholder="e.g., [YKTI RAWAT]"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  DELAY (SECONDS)
                </label>
                <input
                  type="number"
                  value={config.delay}
                  onChange={(e) => setConfig({ ...config, delay: parseInt(e.target.value) })}
                  className="input-field"
                  min="1"
                  max="300"
                />
              </div>

              {/* Cookie Mode Selection */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-4">
                  <FaCookie className="inline mr-2" />
                  COOKIE MODE
                </label>
                <div className="flex gap-4">
                  <button
                    onClick={() => setConfig({ ...config, cookieMode: 'single' })}
                    className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all ${
                      config.cookieMode === 'single'
                        ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    SINGLE COOKIE
                  </button>
                  <button
                    onClick={() => setConfig({ ...config, cookieMode: 'multiple' })}
                    className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all ${
                      config.cookieMode === 'multiple'
                        ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    MULTIPLE COOKIES
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {/* Cookie Input */}
              {config.cookieMode === 'single' ? (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    FACEBOOK COOKIE (PASTE)
                  </label>
                  <textarea
                    value={config.singleCookie}
                    onChange={(e) => setConfig({ ...config, singleCookie: e.target.value })}
                    className="input-field min-h-[150px]"
                    placeholder="Paste your Facebook cookie here..."
                  />
                  <button
                    onClick={() => cookieFileRef.current?.click()}
                    className="mt-2 w-full py-2 px-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    <FaFileUpload className="inline mr-2" />
                    OR UPLOAD COOKIE FILE
                  </button>
                  <input
                    ref={cookieFileRef}
                    type="file"
                    accept=".txt"
                    onChange={handleCookieFileUpload}
                    className="hidden"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    MULTIPLE COOKIES (UPLOAD FILE)
                  </label>
                  <div className="border-2 border-dashed border-pink-300 rounded-xl p-6 text-center">
                    <FaFileUpload className="text-5xl text-pink-500 mx-auto mb-4" />
                    <p className="text-gray-600 font-medium mb-4">
                      Upload cookies.txt file
                    </p>
                    <button
                      onClick={() => cookieFileRef.current?.click()}
                      className="btn-primary"
                    >
                      CHOOSE FILE
                    </button>
                    <input
                      ref={cookieFileRef}
                      type="file"
                      accept=".txt"
                      onChange={handleCookieFileUpload}
                      className="hidden"
                    />
                    {config.multipleCookies && (
                      <p className="mt-4 text-green-600 font-bold">
                        ✅ {config.multipleCookies.split('\n').filter(l => l.trim()).length} cookies loaded
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Messages Input */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  MESSAGES
                </label>
                <textarea
                  value={config.messages}
                  onChange={(e) => setConfig({ ...config, messages: e.target.value })}
                  className="input-field min-h-[150px]"
                  placeholder="Enter messages (one per line) or upload a file..."
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-2 w-full py-2 px-4 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                >
                  <FaFileUpload className="inline mr-2" />
                  UPLOAD MESSAGE FILE
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>
          </div>

          {saveMessage.text && (
            <div
              className={`mt-6 p-4 rounded-xl font-bold ${
                saveMessage.type === 'success'
                  ? 'bg-green-100 text-green-700 border-2 border-green-300'
                  : 'bg-red-100 text-red-700 border-2 border-red-300'
              }`}
            >
              {saveMessage.text}
            </div>
          )}

          <button
            onClick={handleSaveConfig}
            className="w-full mt-8 btn-primary text-xl py-4"
          >
            💾 SAVE CONFIGURATION
          </button>
        </div>
      )}

      {/* Automation Tab */}
      {activeTab === 'automation' && (
        <div className="glass-card rounded-3xl p-6 md:p-10 fade-in">
          <h2 className="text-3xl font-black gradient-text mb-8">🚀 AUTOMATION CONTROL</h2>
          
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <button
              onClick={handleStartAutomation}
              disabled={isRunning || !config.chatId}
              className="btn-primary text-xl py-6 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <FaPlay className="inline mr-2" />
              START AUTOMATION
            </button>
            
            <button
              onClick={handleStopAutomation}
              disabled={!isRunning}
              className="btn-secondary text-xl py-6 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <FaStop className="inline mr-2" />
              STOP AUTOMATION
            </button>
          </div>

          {/* Console Output */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-black text-gray-700">📊 LIVE CONSOLE OUTPUT</h3>
              <button
                onClick={() => setLogs([])}
                className="text-red-500 hover:text-red-700 font-bold"
              >
                <FaTrash className="inline mr-2" />
                CLEAR LOGS
              </button>
            </div>
            <div className="console-output">
              {logs.length === 0 ? (
                <p className="text-gray-500">No logs yet. Start automation to see logs...</p>
              ) : (
                logs.slice(-30).map((log, index) => (
                  <div key={index} className="mb-1">
                    <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> {log}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="text-center mt-8">
        <p className="text-gray-600 font-bold">
          MADE WITH ❤️ BY YKTI RAWAT | © 2026
        </p>
      </div>
    </div>
  );
}
