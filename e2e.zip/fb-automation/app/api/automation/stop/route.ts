import { NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth';
import { setAutomationRunning } from '@/lib/database';
import { stopAutomation } from '@/lib/automation';

export async function POST() {
  try {
    const session = await getServerSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }

    await stopAutomation();
    setAutomationRunning(session.userId, false);

    return NextResponse.json({
      success: true,
      message: 'Automation stopped successfully',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Server error' },
      { status: 500 }
    );
  }
}
