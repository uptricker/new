import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth';
import { setAutomationRunning, addLog } from '@/lib/database';
import { startAutomation } from '@/lib/automation';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const config = await request.json();

    if (!config.chatId) {
      return NextResponse.json(
        { success: false, message: 'Chat ID is required' },
        { status: 400 }
      );
    }

    if (!config.messages || config.messages.trim() === '') {
      return NextResponse.json(
        { success: false, message: 'Messages are required' },
        { status: 400 }
      );
    }

    // Parse messages
    const messageList = config.messages
      .split('\n')
      .map((m: string) => m.trim())
      .filter((m: string) => m.length > 0);

    if (messageList.length === 0) {
      return NextResponse.json(
        { success: false, message: 'At least one message is required' },
        { status: 400 }
      );
    }

    // Start automation in background
    const automationConfig = {
      userId: session.userId,
      chatId: config.chatId,
      namePrefix: config.namePrefix || '',
      delay: config.delay || 30,
      cookieMode: config.cookieMode || 'single',
      singleCookie: config.singleCookie || '',
      multipleCookies: config.multipleCookies || '',
      messages: messageList,
    };

    // Start automation (this will run in background)
    startAutomation(automationConfig, (log) => {
      addLog(session.userId, log, 'info');
    }).catch((error) => {
      addLog(session.userId, `Error: ${error.message}`, 'error');
      setAutomationRunning(session.userId, false);
    });

    setAutomationRunning(session.userId, true);

    return NextResponse.json({
      success: true,
      message: 'Automation started successfully',
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message || 'Server error' },
      { status: 500 }
    );
  }
}
