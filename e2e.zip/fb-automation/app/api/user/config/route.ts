import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth';
import { getUserConfig, updateUserConfig } from '@/lib/database';

export async function GET() {
  try {
    const session = await getServerSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const config = getUserConfig(session.userId);
    
    if (!config) {
      return NextResponse.json(
        { success: false, message: 'Config not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      username: session.username,
      userId: session.userId,
      config: {
        chatId: config.chat_id || '',
        namePrefix: config.name_prefix || '',
        delay: config.delay || 30,
        cookieMode: config.cookie_mode || 'single',
        singleCookie: config.single_cookie || '',
        multipleCookies: config.multiple_cookies || '',
        messages: config.messages || '',
        automation_running: config.automation_running || 0,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Server error' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const data = await request.json();

    updateUserConfig(
      session.userId,
      data.chatId || '',
      data.namePrefix || '',
      data.delay || 30,
      data.cookieMode || 'single',
      data.singleCookie || '',
      data.multipleCookies || '',
      data.messages || ''
    );

    return NextResponse.json({
      success: true,
      message: 'Configuration updated successfully',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Server error' },
      { status: 500 }
    );
  }
}
