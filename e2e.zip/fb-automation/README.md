# 🦂 YKTI RAWAT - FB Automation Pro

Premium Facebook E2EE Automation System - Vercel Ready ✅

## ✨ Features

- 🔐 **Secure Authentication** - JWT + bcrypt
- 🍪 **Dual Cookie Mode** - Single or Multiple cookies
- 📁 **File Uploads** - Messages.txt & Cookies.txt
- 🎨 **Premium UI** - Modern gradient design
- 📊 **Live Monitoring** - Real-time console logs
- 💾 **SQLite Database** - Persistent storage
- 🚀 **Vercel Optimized** - 100% working deployment

## 🚀 Quick Start (Local)

```bash
# 1. Install dependencies
npm install

# 2. Setup environment
cp .env.example .env.local

# Edit .env.local and add:
JWT_SECRET=your-random-secret-key-here

# 3. Run development server
npm run dev

# Open http://localhost:3000
```

## 🌐 Deploy to Vercel (FIXED VERSION)

### Method 1: Vercel CLI (Recommended)

```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Login
vercel login

# 3. Deploy
vercel

# Follow prompts and say YES to all

# 4. Add environment variable
vercel env add JWT_SECRET production

# When prompted, enter a strong secret:
# Example: MySecretKey12345XYZ789ABC

# 5. Deploy to production
vercel --prod

# Done! Your URL will be shown
```

### Method 2: GitHub + Vercel Dashboard

```bash
# 1. Initialize git
git init
git add .
git commit -m "Initial commit"

# 2. Create GitHub repo and push
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main

# 3. Go to vercel.com
# - Click "New Project"
# - Import your GitHub repo
# - Add Environment Variable:
#   Name: JWT_SECRET
#   Value: YourSecretKey123
# - Click "Deploy"

# Wait 5-10 minutes - Done!
```

## 🔧 Environment Variables (IMPORTANT)

You MUST set this on Vercel:

```
JWT_SECRET=your-very-secret-random-key
```

### How to add on Vercel Dashboard:
1. Go to your project
2. Settings → Environment Variables
3. Add: 
   - Key: `JWT_SECRET`
   - Value: `YourRandomSecretKey123`
   - Environment: Production
4. Redeploy

### How to add via CLI:
```bash
vercel env add JWT_SECRET production
# Enter your secret when prompted
vercel --prod
```

## 📖 How to Use

### 1. Create Account
- Visit your Vercel URL
- Click "SIGN UP"
- Enter username & password
- Click "CREATE ACCOUNT"

### 2. Login
- Enter credentials
- Click "LOGIN NOW"

### 3. Configure

#### Get Chat ID:
```
1. Open Facebook Messenger
2. Open your target conversation
3. Copy ID from URL:
   
   URL: https://www.facebook.com/messages/t/1362400298935018
   Chat ID: 1362400298935018
```

#### Setup Cookies:

**Single Cookie Mode:**
```
1. Click "SINGLE COOKIE" button
2. Paste your Facebook cookie
   OR
3. Click "OR UPLOAD COOKIE FILE"
4. Upload cookie.txt
```

**Multiple Cookie Mode:**
```
1. Click "MULTIPLE COOKIES" button
2. Click "CHOOSE FILE"
3. Upload cookies.txt (one cookie per line)
```

#### Setup Messages:
```
1. Type messages directly (one per line)
   OR
2. Click "UPLOAD MESSAGE FILE"
3. Upload messages.txt
```

### 4. Start Automation
- Go to "AUTOMATION CONTROL" tab
- Click "START AUTOMATION"
- Monitor live logs

## 🍪 How to Get Facebook Cookies

### Method 1: EditThisCookie (Chrome)
```
1. Install "EditThisCookie" extension
2. Login to Facebook
3. Click extension icon
4. Click "Export"
5. Paste in app
```

### Method 2: Browser DevTools
```
1. Login to Facebook
2. Press F12
3. Go to Application → Cookies → facebook.com
4. Copy these cookies:
   - c_user
   - xs
   - datr
   - fr
   
5. Format: c_user=VALUE; xs=VALUE; datr=VALUE; fr=VALUE;
```

## 📂 Project Structure

```
fb-automation/
├── app/
│   ├── api/              # API routes
│   ├── dashboard/        # Main dashboard
│   ├── login/           # Login page
│   └── layout.tsx       # Root layout
├── lib/
│   ├── auth.ts          # JWT auth
│   ├── database.ts      # SQLite DB
│   └── automation.ts    # Automation logic
├── package.json
├── next.config.js
└── vercel.json          # Vercel config
```

## 🛠️ Troubleshooting

### 404 Error on Vercel

This means deployment failed. Fix:

```bash
# 1. Make sure you're in the right directory
cd fb-automation

# 2. Check if package.json exists
ls -la package.json

# 3. Redeploy
vercel --prod --force

# 4. If still failing, check build logs on Vercel dashboard
```

### "Unauthorized" Error

```bash
# Make sure JWT_SECRET is set on Vercel
vercel env ls

# If not showing, add it:
vercel env add JWT_SECRET production

# Redeploy
vercel --prod
```

### Database Errors

```bash
# Locally: Delete and recreate
rm -rf data/
npm run dev

# On Vercel: Redeploy
vercel --prod --force
```

### Cookies Not Working

```
✅ Use fresh cookies (login again)
✅ Try incognito mode cookies
✅ Check cookie format
✅ Make sure c_user and xs cookies are present
```

## ⚡ Performance Tips

```
Delay: 30-60 seconds (recommended)
Messages: Natural, varied content
Cookies: Refresh every 7 days
Monitoring: Check logs daily
```

## 🔐 Security

- ✅ Passwords hashed with bcrypt
- ✅ JWT tokens for sessions
- ✅ Environment variables for secrets
- ✅ SQL injection protection
- ✅ HTTPS on Vercel

## 📝 Important Notes

### About Automation:
- This simulates message sending
- For production, integrate with Facebook Graph API
- Respect Facebook's rate limits
- Don't spam

### About Vercel:
- Free tier has function timeout (10 seconds)
- Automation will pause after timeout
- Restart manually when needed
- For 24/7, use Vercel Pro or VPS

## 🆘 Support

If you have issues:

1. Check this README
2. Review Vercel deployment logs
3. Check environment variables
4. Try redeploying
5. Check browser console for errors

## 📚 Additional Files

- `DEPLOYMENT_GUIDE.md` - Detailed deployment steps
- `COOKIE_GUIDE.md` - How to get cookies
- `example-messages.txt` - Sample messages

## 🎯 Features Checklist

✅ Single Cookie Mode
✅ Multiple Cookie Mode  
✅ Message File Upload
✅ Cookie File Upload
✅ Premium Professional UI
✅ Live Console Logs
✅ Secure Authentication
✅ Vercel Deployment
✅ Responsive Design
✅ Auto-save Config

## 📄 License

For educational purposes only. Use responsibly.

## 👨‍💻 Developer

**YKTI RAWAT**
Made with ❤️ in 2026

---

**Enjoy your Premium FB Automation System! 🚀**
