#!/bin/bash

# FB Automation Pro - One-Click Deployment Script
# Made by YKTI RAWAT

echo "🦂 FB Automation Pro - Deployment Script"
echo "=========================================="
echo ""

# Check if in correct directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found!"
    echo "Please run this script from the fb-automation directory"
    exit 1
fi

echo "✅ Found package.json"
echo ""

# Install Vercel CLI if not installed
if ! command -v vercel &> /dev/null; then
    echo "📦 Installing Vercel CLI..."
    npm install -g vercel
    echo "✅ Vercel CLI installed"
else
    echo "✅ Vercel CLI already installed"
fi

echo ""
echo "🚀 Starting deployment..."
echo ""

# Deploy to Vercel
vercel --prod

echo ""
echo "=========================================="
echo "✅ Deployment initiated!"
echo ""
echo "Next steps:"
echo "1. Check your Vercel dashboard for deployment status"
echo "2. Add JWT_SECRET environment variable if not added:"
echo "   vercel env add JWT_SECRET production"
echo "3. Visit your deployment URL"
echo ""
echo "Made with ❤️ by YKTI RAWAT"
