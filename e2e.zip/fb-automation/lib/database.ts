import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import path from 'path';
import { existsSync, mkdirSync } from 'fs';

const dbDir = path.join(process.cwd(), 'data');
if (!existsSync(dbDir)) {
  mkdirSync(dbDir, { recursive: true });
}

const db = new Database(path.join(dbDir, 'automation.db'));

// Initialize database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS user_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    chat_id TEXT,
    name_prefix TEXT,
    delay INTEGER DEFAULT 30,
    cookie_mode TEXT DEFAULT 'single',
    single_cookie TEXT,
    multiple_cookies TEXT,
    messages TEXT,
    automation_running INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS automation_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    message TEXT,
    status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

export interface User {
  id: number;
  username: string;
  password: string;
  created_at: string;
}

export interface UserConfig {
  id: number;
  user_id: number;
  chat_id: string;
  name_prefix: string;
  delay: number;
  cookie_mode: 'single' | 'multiple';
  single_cookie: string;
  multiple_cookies: string;
  messages: string;
  automation_running: number;
  created_at: string;
  updated_at: string;
}

export interface AutomationLog {
  id: number;
  user_id: number;
  message: string;
  status: string;
  created_at: string;
}

// User operations
export function createUser(username: string, password: string): { success: boolean; message: string; userId?: number } {
  try {
    const hashedPassword = bcrypt.hashSync(password, 10);
    const stmt = db.prepare('INSERT INTO users (username, password) VALUES (?, ?)');
    const result = stmt.run(username, hashedPassword);
    
    // Create default config for user
    const configStmt = db.prepare(`
      INSERT INTO user_configs (user_id, chat_id, name_prefix, delay, cookie_mode, single_cookie, multiple_cookies, messages)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    configStmt.run(result.lastInsertRowid, '', '', 30, 'single', '', '', '');
    
    return { success: true, message: 'User created successfully', userId: result.lastInsertRowid as number };
  } catch (error: any) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return { success: false, message: 'Username already exists' };
    }
    return { success: false, message: 'Error creating user' };
  }
}

export function verifyUser(username: string, password: string): { success: boolean; userId?: number } {
  const stmt = db.prepare('SELECT id, password FROM users WHERE username = ?');
  const user = stmt.get(username) as User | undefined;
  
  if (user && bcrypt.compareSync(password, user.password)) {
    return { success: true, userId: user.id };
  }
  return { success: false };
}

export function getUserConfig(userId: number): UserConfig | null {
  const stmt = db.prepare('SELECT * FROM user_configs WHERE user_id = ?');
  return stmt.get(userId) as UserConfig | null;
}

export function updateUserConfig(
  userId: number,
  chatId: string,
  namePrefix: string,
  delay: number,
  cookieMode: 'single' | 'multiple',
  singleCookie: string,
  multipleCookies: string,
  messages: string
): void {
  const stmt = db.prepare(`
    UPDATE user_configs 
    SET chat_id = ?, name_prefix = ?, delay = ?, cookie_mode = ?, 
        single_cookie = ?, multiple_cookies = ?, messages = ?, updated_at = CURRENT_TIMESTAMP
    WHERE user_id = ?
  `);
  stmt.run(chatId, namePrefix, delay, cookieMode, singleCookie, multipleCookies, messages, userId);
}

export function setAutomationRunning(userId: number, running: boolean): void {
  const stmt = db.prepare('UPDATE user_configs SET automation_running = ? WHERE user_id = ?');
  stmt.run(running ? 1 : 0, userId);
}

export function getAutomationRunning(userId: number): boolean {
  const stmt = db.prepare('SELECT automation_running FROM user_configs WHERE user_id = ?');
  const result = stmt.get(userId) as { automation_running: number } | undefined;
  return result?.automation_running === 1;
}

export function addLog(userId: number, message: string, status: string): void {
  const stmt = db.prepare('INSERT INTO automation_logs (user_id, message, status) VALUES (?, ?, ?)');
  stmt.run(userId, message, status);
}

export function getLogs(userId: number, limit: number = 50): AutomationLog[] {
  const stmt = db.prepare('SELECT * FROM automation_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?');
  return stmt.all(userId, limit) as AutomationLog[];
}

export default db;
