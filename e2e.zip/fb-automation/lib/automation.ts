import { addLog } from './database';

interface AutomationConfig {
  userId: number;
  chatId: string;
  namePrefix: string;
  delay: number;
  cookieMode: 'single' | 'multiple';
  singleCookie: string;
  multipleCookies: string;
  messages: string[];
}

let isRunning = false;
let automationInterval: NodeJS.Timeout | null = null;

export async function startAutomation(config: AutomationConfig, onLog: (log: string) => void): Promise<void> {
  if (isRunning) {
    throw new Error('Automation is already running');
  }

  isRunning = true;

  try {
    onLog('🚀 Starting automation...');
    addLog(config.userId, 'Automation started', 'info');

    // Validate cookies
    if (config.cookieMode === 'single' && config.singleCookie) {
      onLog('✅ Single cookie mode enabled');
    } else if (config.cookieMode === 'multiple' && config.multipleCookies) {
      const cookieList = config.multipleCookies.split('\n').filter(c => c.trim());
      onLog(`✅ Multiple cookie mode: ${cookieList.length} cookies loaded`);
    } else {
      throw new Error('No cookies provided');
    }

    onLog(`🌐 Target chat: ${config.chatId}`);
    onLog(`⏱️ Delay: ${config.delay} seconds`);
    onLog(`📝 Messages: ${config.messages.length} messages loaded`);

    // Simulate message sending
    let messageIndex = 0;
    
    const sendMessages = async () => {
      if (!isRunning) return;

      const message = config.messages[messageIndex % config.messages.length];
      const finalMessage = config.namePrefix ? `${config.namePrefix} ${message}` : message;

      try {
        // Simulate API call to send message
        await simulateSendMessage(config.chatId, finalMessage, config);
        
        onLog(`📨 Message sent: ${finalMessage.substring(0, 50)}...`);
        addLog(config.userId, `Message sent: ${finalMessage}`, 'success');
        messageIndex++;
      } catch (error: any) {
        onLog(`❌ Error: ${error.message}`);
        addLog(config.userId, `Error: ${error.message}`, 'error');
      }

      if (isRunning) {
        onLog(`⏳ Waiting ${config.delay} seconds before next message...`);
      }
    };

    // Send first message
    await sendMessages();

    // Schedule subsequent messages
    automationInterval = setInterval(sendMessages, config.delay * 1000);

  } catch (error: any) {
    onLog(`❌ Fatal error: ${error.message}`);
    addLog(config.userId, `Fatal error: ${error.message}`, 'error');
    isRunning = false;
    throw error;
  }
}

export async function stopAutomation(): Promise<void> {
  isRunning = false;
  if (automationInterval) {
    clearInterval(automationInterval);
    automationInterval = null;
  }
}

async function simulateSendMessage(chatId: string, message: string, config: AutomationConfig): Promise<void> {
  // This simulates sending a message via Facebook API
  // In production, you would use Facebook's Graph API or a proper automation service
  
  const cookies = config.cookieMode === 'single' 
    ? config.singleCookie 
    : config.multipleCookies.split('\n')[0];

  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

  // In a real implementation, you would:
  // 1. Parse the cookies
  // 2. Make authenticated requests to Facebook
  // 3. Send the actual message
  
  // For now, we just simulate success
  if (Math.random() > 0.95) { // 5% chance of simulated error
    throw new Error('Simulated network error');
  }
}

export function isAutomationRunning(): boolean {
  return isRunning;
}
